document.getElementById('.program-indi').addEventListener('click', openPopup);

    function openPopup() {
    document.getElementById('popupContainer').style.display = 'flex';
    }

    function closePopup() {
    document.getElementById('popupContainer').style.display = 'none';
    }